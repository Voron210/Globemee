##Hello

##What's used
React
React Cotext - state management
React Hook Form -  from validation
Aaxios, rest api, websocket

##What's in the plans
Change state management to React toolkit
RTK Querry
Rewrite everything to TypeScript
It is also worth paying attention to MobX, SASS
and refactoring, refactoring, refactoring...


#PS
30.09.2024 - The development of the frontend part has been stopped until better times
