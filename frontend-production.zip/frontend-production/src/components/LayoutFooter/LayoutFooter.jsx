import React from "react";

const LayoutFooter = () => {
  return (
    <>
      <footer>LayoutFooter</footer>
    </>
  );
};
export default LayoutFooter;
