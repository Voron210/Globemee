const JobOffer = {
  degree: [
    {
      option: "Berufsausbildung",
    },
    {
      option: "Bachelor",
    },
    {
      option: "Master / Diplom",
    },
    {
      option: "PhD / Doktor",
    },
    {
      option: "Techniker",
    },
    {
      option: "Meister",
    },
  ],
};

export default JobOffer;
